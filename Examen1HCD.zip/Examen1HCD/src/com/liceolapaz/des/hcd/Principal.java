package com.liceolapaz.des.hcd;

import java.sql.SQLOutput;
import java.util.Random;
import java.util.Scanner;

public class Principal {
    public static void main(String[] args) {
        int altura = 0;
        String posicion = "";
        String[] posicionesValidas = {"Base","Escolta","Alero","Ala-Pívot","Pivot"};
        int tiro2=0;
        int tiro3=0;
        int pase=0;
        int defensa=0;
        int velocidad=0;
        int puntosExtra=0;
        while(true){
            menu();
            int datoMenu = almacenarDatoInt();
            switch (datoMenu){
                case 1:
                    altura = numAleatorio(160,235);
                    break;
                case 2:
                    posicion = posicionesValidas[numAleatorio(0,4)];
                    break;
                case 3:
                    tiro2 = numAleatorio(1,99);
                    tiro3 = numAleatorio(1,99);
                    pase = numAleatorio(1,99);
                    defensa = numAleatorio(1,99);
                    velocidad = numAleatorio(1,99);
                    puntosExtra = 40;
                    break;
                case 4:
                    if(puntosExtra <= 0){
                        System.out.println("¡¡ERROR, no tienes puntos extra!!");
                        break;
                    }
                    System.out.print("A que habilidad quieres asignarle puntos extra: ");
                    String habilidad = almacenarDatoString().toLowerCase();
                        switch (habilidad){
                            case "tiro2":
                                System.out.print("¿¿Cuantos puntos extra quieres asignarle?? --> ");
                                int puntosAsignados = almacenarDatoInt();
                                if(puntosAsignados > puntosExtra){
                                    System.out.println("¡¡No puedes asignar esa cantidad de puntos!!");
                                    break;
                                }
                                if((tiro2 += puntosAsignados)>99){
                                    System.out.println("No puedes añadirle esos puntos, el tiro2 tiene: "+tiro2);
                                    break;
                                }
                                puntosExtra -= puntosAsignados;
                                break;
                            case "tiro3":
                                System.out.print("¿¿Cuantos puntos extra quieres asignarle?? --> ");
                                puntosAsignados = almacenarDatoInt();
                                if(puntosAsignados > puntosExtra){
                                    System.out.println("¡¡No puedes asignar esa cantidad de puntos!!");
                                    break;
                                }
                                if((tiro3 += puntosAsignados)>99){
                                    System.out.println("No puedes añadirle esos puntos, el tiro3 tiene: "+tiro3);
                                    break;
                                }
                                puntosExtra -= puntosAsignados;
                                break;
                            case "pase":
                                System.out.print("¿¿Cuantos puntos extra quieres asignarle?? --> ");
                                puntosAsignados = almacenarDatoInt();
                                if(puntosAsignados > puntosExtra){
                                    System.out.println("¡¡No puedes asignar esa cantidad de puntos!!");
                                    break;
                                }
                                if((pase += puntosAsignados)>99){
                                    System.out.println("No puedes añadirle esos puntos, el pase tiene: "+pase);
                                    break;
                                }
                                puntosExtra -= puntosAsignados;
                                break;
                            case "defensa":
                                System.out.print("¿¿Cuantos puntos extra quieres asignarle?? --> ");
                                puntosAsignados = almacenarDatoInt();
                                if(puntosAsignados > puntosExtra){
                                    System.out.println("¡¡No puedes asignar esa cantidad de puntos!!");
                                    break;
                                }
                                if((defensa += puntosAsignados)>99){
                                    System.out.println("No puedes añadirle esos puntos, el defensa tiene: "+defensa);
                                    break;
                                }
                                puntosExtra -= puntosAsignados;
                                break;
                            case "velocidad":
                                System.out.print("¿¿Cuantos puntos extra quieres asignarle?? --> ");
                                puntosAsignados = almacenarDatoInt();
                                if(puntosAsignados > puntosExtra){
                                    System.out.println("¡¡No puedes asignar esa cantidad de puntos!!");
                                    break;
                                }
                                if((velocidad += puntosAsignados)>99){
                                    System.out.println("No puedes añadirle esos puntos, el velocidad tiene: "+velocidad);
                                    break;
                                }
                                puntosExtra -= puntosAsignados;
                                break;
                            default:
                                System.out.println("¡¡ No existe esa habilidad !!");
                        }
                    System.out.println("Tienes "+puntosExtra+" puntos extra restantes");
                    break;
                case 5:
                    System.out.println("Altura: "+ altura+"\n"+
                            "Posición: " + posicion +"\n"+
                            "Tiro 2 Puntos: " + tiro2 +"\n"+
                            "Tiro 3 Puntos: " + tiro3 +"\n"+
                            "Pase: " + pase +"\n"+
                            "Defensa: " + defensa +"\n"+
                            "Velocidad: " + velocidad +"\n"+
                            "Media Habilidades: "+(tiro2+tiro3+pase+defensa+velocidad)/5);
                    break;
                case 0:
                    System.exit(0);
                default:
                    System.out.println("¡¡ERROR, OPCIÓN INTRODUCIDA NO VALIDA!!");
                    break;
            }
        }
    }

    private static String almacenarDatoString(){
        Scanner sc = new Scanner(System.in);
        return sc.next();
    }

    private static int almacenarDatoInt() {
        Scanner sc = new Scanner(System.in);
        return sc.nextInt();
    }

    private static int numAleatorio(int min, int max){
        return (int) (Math.floor(Math.random()*(max-min+1)+min));
    }

    private static void menu(){
        System.out.print("CREACIÓN JUGADOR\n" +
                "1.Altura\n" +
                "2.Posición\n" +
                "3.Habilidades\n" +
                "4.Puntos extra\n" +
                "5.Mostrar jugador\n" +
                "0.Salir\n" +
                "Escoja una opción: ");
    }
}
