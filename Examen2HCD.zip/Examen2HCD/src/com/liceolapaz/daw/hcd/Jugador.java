package com.liceolapaz.daw.hcd;

import java.util.Scanner;

public class Jugador {
    private int id;
    private String nombre;
    private String nacionalidad;
    private int edad;
    private String posicion;

    public Jugador(int id ,String nombre, String nacionalidad, int edad, String posicion) {
        this.nombre = nombre;
        this.nacionalidad = nacionalidad;
        this.edad = edad;
        this.posicion = posicion;
        this.id = id;
    }

    public static Jugador crearJugador(){
        Scanner sc = new Scanner(System.in);
        System.out.print("Identificador de jugador: ");
        int id = sc.nextInt();
        System.out.print("Introduzca el nombre del jugador: ");
        String nombre = sc.next();
        System.out.print("Introduzca la nacionalidad: ");
        String nacionalidad = sc.next();
        System.out.print("Introduzca la edad: ");
        int edad = sc.nextInt();
        System.out.print("Introduzca la posición: ");
        String posicion = sc.next();

        return new Jugador(id,nombre,nacionalidad,edad,posicion);
    }

    public int getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public String getNacionalidad() {
        return nacionalidad;
    }

    public String getPosicion() {
        return posicion;
    }

    public int getEdad() {
        return edad;
    }

    public String toString(){
        return "Id : "+id + " Posición : "+posicion+" Nombre: "+nombre+" Nacionalidad: "+nacionalidad+", Edad: "+edad+" años";
    }
}
