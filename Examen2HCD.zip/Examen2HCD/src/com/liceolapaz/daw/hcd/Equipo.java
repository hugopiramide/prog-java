package com.liceolapaz.daw.hcd;

import java.util.Scanner;

public class Equipo {

    private static Jugador[] jugadores = new Jugador[15];
    private static int contadorJugadorEquipo = 0;

    private String nombre;
    private String ciudad;
    private String nombreEstadio;
    private int capacidad;

    public Equipo(String nombre, String ciudad, String nombreEstadio, int capacidad) {
        this.nombre = nombre;
        this.ciudad = ciudad;
        this.nombreEstadio = nombreEstadio;
        this.capacidad = capacidad;

        Jugador[] jugadores = new Jugador[15];// Cada equipo tiene 15 jugadores en total MÁXIMO
    }

    public static Equipo crearEquipo(){
        Scanner sc = new Scanner(System.in);
        System.out.print("Introduzca el nombre del equipo: ");
        String nombre = sc.next();
        System.out.print("Introduzca el nombre de la ciudad : ");
        String ciudad = sc.next();
        System.out.print("Introduzca el nombre del Estadio: ");
        String nombreEstadio = sc.next();
        System.out.print("Introduzca la capacidad del Estadio : ");
        int capacidad = sc.nextInt();

        return new Equipo(nombre,ciudad,nombreEstadio,capacidad);
    }

    public void ficharJugador(Jugador jugador){
        if(contadorJugadorEquipo >= 15){
            System.out.println("MÁXIMO DE JUGADORES EN LA PLANTILLA ALCANZADO");
        }
        else {
            jugadores[contadorJugadorEquipo] = jugador;
            contadorJugadorEquipo++;
        }
    }

    public static void eliminarJugador(Jugador jugador){

    }

    public String getNombre() {
        return nombre;
    }

    public String toString(){
        return nombre + " - " +ciudad+ " - "+  nombreEstadio + " - "+ capacidad + " Espectadores";
    }
}
