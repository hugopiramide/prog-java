package com.liceolapaz.daw.hcd;

import java.util.Scanner;

public class Gestor {

    //Al programa le falta eliminar jugadores de la plantilla

    private final static Scanner sc = new Scanner(System.in);
    private static Jugador[] jugadoresSinFichar = new Jugador[270];
    private static Equipo[] equipos = new Equipo[18];
    private static int contadorEquipos = 0;
    private static int contadorJugadores = 0;

    public static void main(String[] args) {
        while (true){
            menu();
            int opcion = sc.nextInt();
            switch (opcion){
                case 0:
                    System.exit(0);
                    break;
                case 1:
                    if(contadorEquipos >= 17){
                        System.out.println("ERROR, NO PUEDES CREAR MÁS EQUIPOS");
                        break;
                    }
                    equipos[contadorEquipos] = Equipo.crearEquipo();
                    contadorEquipos++;
                    break;
                case 2:
                    if(contadorJugadores >= 270){
                        System.out.println("ERROR, NO PUEDES INTRODUCIR MÁS JUGADORES");
                    }
                    jugadoresSinFichar[contadorJugadores] = Jugador.crearJugador();//añadimos a jugadoresSinFichar
                    contadorJugadores++;
                    break;
                case 3:
                    transferirJugador();
                    break;
                case 4:
                    listarJugadoresSinEquipo();
                    break;
                case 5:
                    System.out.println(mostrarEquipo());
                    break;
                default:
                    System.out.println("ERROR, Opcion del menú no existente");
                    break;
            }
        }
    }

    public static void menu(){
        System.out.print("LIGA BALONCESTO\n" +
                "1. Añadir equipo\n" +
                "2. Añadir jugador\n" +
                "3. Transferir jugador\n" +
                "4. Listar jugadores sin equipo\n" +
                "5. Mostrar equipo\n" +
                "0. Salir\n" +
                "Escoja una opción: ");
    }

    public static void transferirJugador(){
        System.out.print("Introduzca el ID del jugador: ");
        int id = sc.nextInt();
        for (int i = 0; i < jugadoresSinFichar.length - 1; i++){
            if (jugadoresSinFichar[i] != null && jugadoresSinFichar[i].getId() == id){
                System.out.print("Quiere añadir este jugador a un equipo (y) o Quiere quitar a este jugador de un equipo (n) : ");
                if(sc.next().equalsIgnoreCase("y")){
                    Equipo equipo = comprobarExistenciaEquipo();
                    if(equipo != null){
                        ficharJugador(equipo , jugadoresSinFichar[i]);
                        return;
                    }
                    else{
                        System.out.println("ERROR, EL EQUIPO NO EXISTE");
                    }
                }
            }
        }
    }

    public static void ficharJugador(Equipo equipo, Jugador jugador){
        equipo.ficharJugador(jugador);
    }

    public static Equipo comprobarExistenciaEquipo(){
        System.out.println("Introduzca el equipo: ");
        String equipo = sc.next();
        System.out.print("Indique el equipo: ");
        for (int i = 0; i < equipos.length - 1; i++){
            if (equipos[i] != null && equipos[i].getNombre().equalsIgnoreCase(equipo)){
                return equipos[i];
            }
        }
        return null;
    }

    public static String mostrarEquipo(){
        System.out.print("Indique el equipo: ");
        String equipo = sc.next();
        for (int i = 0; i < equipos.length - 1; i++){
            if (equipos[i] != null && equipos[i].getNombre().equalsIgnoreCase(equipo)){
                return equipos[i].toString();
            }
        }
        return "Equipo no encontrado";
    }

    //public static boolean comprobarExistenciaEquipo(String equipo){
    //    for(int i = 0 ; i < equipos.length - 1; i++){
    //        if(equipos[i] != null && equipos[i].getNombre().equalsIgnoreCase(equipo)){
    //            return true;
    //        }
    //    }
    //    return false;
    //}

    private static void listarJugadoresSinEquipo() {
        for (int i = 0; i < jugadoresSinFichar.length - 1; i++){
            if (jugadoresSinFichar[i] != null){
                System.out.println(jugadoresSinFichar[i].toString());
            }
        }
    }
}
